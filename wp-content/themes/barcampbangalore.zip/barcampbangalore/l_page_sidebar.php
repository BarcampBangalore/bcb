<!-- begin l_page_sidebar -->

<div id="l_sidebar">

<?php //print_r($post); ?>
<?php show_attending_button($post); ?>

</div>

<!-- end l_page_sidebar -->
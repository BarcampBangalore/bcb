<!-- begin footer -->

<div style="clear:both;"></div>

<div id="footer">
	<p>Copyright &copy; 2007 <a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a> &bull; Awesomely Powered by <a href="http://www.wordpress.org">WordPress</a> <?php /* &bull; Using <a href="http://www.briangardner.com/themes/silhouette-wordpress-theme.htm" >Silhouette</a> theme created by <a href="http://www.briangardner.com" >Brian Gardner</a> */ ?></p>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
<?php get_header(); ?>

<div id="content">

	<div id="contentleft">
		<h1>File not found! Ayyo!</h1>
		<p>Bhai, The page you are looking for is missing. What about searching it over there in the search box? hm?</p>
	</div>
	
<?php include(TEMPLATEPATH."/l_sidebar.php");?>

<?php include(TEMPLATEPATH."/r_sidebar.php");?>

</div>

<!-- The main column ends  -->

<?php get_footer(); ?>
<?php /**/ ?><?php
// Silence is golden.
?>
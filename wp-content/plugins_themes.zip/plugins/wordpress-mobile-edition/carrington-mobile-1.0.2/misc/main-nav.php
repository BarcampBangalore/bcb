<?php /**/ ?><a class="to-home" href="<?php bloginfo('home'); ?>">Home</a> |
<?php if(!is_home()){ ?><a href="#recent">Recent Posts</a> | <?php } ?>
<a href="#pages">Pages</a>
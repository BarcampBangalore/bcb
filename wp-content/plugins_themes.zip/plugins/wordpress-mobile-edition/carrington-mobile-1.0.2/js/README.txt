## js/

Organizational folder for holding theme JavaScript files.

This directory is not used by the Carrington engine (template naming conventions are not supported), it is provided solely for convenience and for better organization of these files.
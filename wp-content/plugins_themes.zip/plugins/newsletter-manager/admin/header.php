<style type="text/css">
#xyz-wp-newsletter-premium {
	border: 1px solid #FCC328;
	margin-bottom: 20px;
	margin-top: 20px;
	background-color: #FFF6D6;
	height: 50px;
	padding: 5px;
	width: 98%;
	border-radius:5px;
}
</style>
<div style="clear: both;"></div>
<div id="xyz-wp-newsletter-premium">

	<div style="float: left; padding: 0 5px">
		<h2 style="vertical-align: middle;">
			<a target="_blank"
				href="http://xyzscripts.com/wordpress-plugins/xyz-wp-newsletter/features">Fully
				Featured XYZ WP Newsletter Premium Plugin</a> - Just 29 USD
		</h2>
	</div>
	<div style="float: left; margin-top: 3px">
		<a target="_blank"
			href="http://xyzscripts.com/members/product/purchase/XYZWPNLM"><img class="hoverImages"
			src="<?php  echo plugins_url("newsletter-manager/admin/images/orange_buynow.png"); ?>">
		</a>
	</div>
<div style="float: left; padding: 0 5px">
	<h2 style="vertical-align: middle;text-shadow: 1px 1px 1px #686868">
			( <a 	href="<?php echo admin_url('admin.php?page=newsletter-manager-about');?>">Compare Features</a> ) 
	</h2>		
	</div>
</div>
<style>
	a.xyz_em_link:hover{text-decoration:underline;} 
	.xyz_em_link{text-decoration:none;font-weight: bold} 
</style>

<?php 

if(get_option('xyz_credit_link')=="0"){
	?>
<div style="float:left;background-color: #FFECB3;border-radius:5px;padding: 0px 5px;margin-top: 10px;border: 1px solid #E0AB1B" id="xyz_backlink_div">
	
	Please do a favour by enabling backlink to our site. <a id="xyz_em_backlink" style="cursor: pointer;" >Okay, Enable</a>.
<script type="text/javascript">
jQuery(document).ready(function() {

	jQuery('#xyz_em_backlink').click(function() {
	
jQuery.ajax
	({
	type: "POST",
	url: "<?php echo plugins_url('newsletter-manager/admin/ajax-backlink.php') ?>",
	data: 'enable=1',
	cache: false,
	success: function(html)
	{	
		jQuery("#xyz_backlink_div").html('Thank you for enabling backlink !');
		jQuery("#xyz_backlink_div").css('background-color', '#D8E8DA');
		jQuery("#xyz_backlink_div").css('border', '1px solid #0F801C');
	}
	});
	

});
});
</script>
</div>
	<?php 
}
?>

<style>
#text {margin:50px auto; width:500px}
.hotspot {color:#900; padding-bottom:1px; border-bottom:1px dotted #900; cursor:pointer}

#tt {position:absolute; display:block; }
#tttop {display:block; height:5px; margin-left:5px;}
#ttcont {display:block; padding:2px 10px 3px 7px;  margin-left:-400px; background:#666; color:#FFF}
#ttbot {display:block; height:5px; margin-left:5px; }
</style>

<div style="margin-top: 10px">
<table style="float:right; ">
<tr>
<td  style="float:right;">
	<a onmouseover="tooltip.show('Please help us to keep this plugin free forever by donating a dollar');" onmouseout="tooltip.hide();"  class="xyz_em_link" style="margin-left:8px;margin-right:12px;"  target="_blank" href="http://xyzscripts.com/donate/1">Donate</a>
</td>
<td style="float:right;">
	<a class="xyz_em_link" style="margin-left:8px;" target="_blank" href="http://kb.xyzscripts.com/wordpress-plugins/newsletter-manager/">FAQ</a> |
</td>
<td style="float:right;">
	<a class="xyz_em_link" style="margin-left:8px;" target="_blank" href="http://docs.xyzscripts.com/wordpress-plugins/newsletter-manager/">README</a> |
</td>
<td style="float:right;">
	<a class="xyz_em_link" style="margin-left:8px;" target="_blank" href="http://xyzscripts.com/wordpress-plugins/newsletter-manager/details">About</a> |
</td>
<td style="float:right;">
	<a class="xyz_em_link" target="_blank" href="http://xyzscripts.com">XYZScripts</a> |
</td>

</tr>
</table>
</div>

<div style="clear: both"></div>
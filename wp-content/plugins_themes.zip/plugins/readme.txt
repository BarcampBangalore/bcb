Plugin Name: Wordpress Mobile 
Plugin URI: http://www.andymoore.info/wordpress-mobile-plugin/
Description: 
  Makes your blog work well on mobile phones! 
  Lets you post to your blog from your mobile! 
  Makes you money with Google AdSense for Mobile and AdMob.
Version 1.3 changelog: https://www.nostinghosting.com/devtracker/index.php?cmd=changelog&project_id=6&version_id=2
Author: Andy Moore
Version: 1.3
Author URI: http://www.andymoore.info/
Copyright 2007-2008 Andy Moore (email : andy@andymoore.info)

This program is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 2 of the License, or (at your option) any later 
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE.See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with 
this program; if not, write to the Free Software Foundation, Inc., 59 Temple 
Place, Suite 330, Boston, MA02111-1307USA

Installation:

Upload to your wp-content/plugins folder

Navigate to your plugin manager. Active!

That's it!
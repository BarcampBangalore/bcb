******************************************************* SmashingMagazine & Ricardo Sousa PRESENT TWITTAR ***************************************************************
                                                                                                                                                 
                    
						    _              _  _    _               
						   | |_ __      __(_)| |_ | |_  __ _  _ __ 
   						   | __|\ \ /\ / /| || __|| __|/ _` || '__|
						   | |_  \ V  V / | || |_ | |_| (_| || |   
						    \__|  \_/\_/  |_| \__| \__|\__,_||_|   

                                                       "Twitter Avatars @ Wordpress"


# TYPE:  plugin

# Name:  Twittar

# Description:      This plugin let's you add your user's twitter photos to their comments.
		    Nowadays a lot of your users probably use Twitter on a day-to-day basics. Its time to 
		get advantage of this fact and fill your website with their pictures whenever they comment it.

#Features:

                    - Loads user pic from correspondence with his email adress
                    - If user doens't have a twitter account it is able to load a default image or try first to load 
user's GRAVATAR. If user doesn't have a gravatar it loads the default image. This is a setting
		    - You can set a 2px (you choose the color) border to add to the images
	            - You can choose the size: Our Suggestion: 48px / 48px
                    - You can set a different image from the default ones to load in case user doesn't have twitter 
/ GRAVATAR
                    - It builds a valid image for you (alt, title and etc) with user details.
                    - Ready to let you add a class to the image so you can style it later

# How to use it?

--> At comments

Option A:
                    (1) Connect to FTP and open your template folder (wp-content/themes/yourthemename);
                    (2) Open your comments.php file or the file where the comments bit is placed;

Option B:        
                    (1) Open your Wordpress site admin suite 
                    (2) Click "Appearance" -> Editor -> The Desired file (usually comments.php) 


A & B:

                    (3) You now may search for the place where there are echo of posted comments (might be inside a li).
                    (4) You can now paste the following code directly or create a div with "float:left;" (and add "float:right"
 to the other div that will contain the comment content) and paste the code inside.
                  
              
                  <?php twittar(size, placeholderimg, border, class, usegravatar, rating); ?>
Explanation:

***** YOU MIGHT CHANGE THE NAMES ABOVE FOR THE CORRECT VALUE!!! ******

+ size: the size of the images (will be both width and height). Ex: "45" ( NO PX !!!!!!!)

+ placeholderimg: If you DON'T WANT to use the default placeholder img that comes with this plugin insert here the complete URL 
of the image you want. ex. "http://www.ricardojrsousa.com/myimg.jpg"

+border: Inser the hexadecimal code of the border IF, and only IF, you want it. ex: "#CCCCCC"

+ class: css class that you might want to add to the image. ex: "myimg"

+ usegravatar: IMPORTANT! Decide if you want to use gravatar if the twitter img is not avaliable/user has no twitter. If user
 hasn't a gravatar it will add the default or the placeholder img as well. ex: 1 / 0 deppending if you want (1) or not (0)

+ rating: JUST FOR GRAVATAR! The rating to which you want to show avatars. ex: "G"


___ NOTES ___

+ If you want to skip a setting (image that you don't want to add a placeholder) but you want to add the following parameter addd
 "" in its place. For example if i want to give the border, usegravatar & rating parameter only i will add:

<?php twittar("", "", "#CCCCCC", "", 1, "R"); ?>


+ Pay attention to the "" and the , -> They are necessary!


****************************************************************************


                       (5) Save the file and enjoy


--> Outside

Follow the step 4 but add it wherever you want.



# Support: www.ricardojrsousa.com

# Licence: GNU GPL v3

# Price: Free for SmashingMagazine Readers

# Release Date:   January 2009

# ChangeLog:

3th January:
* Initial Release





*****************************************************************************************************************************************************

                       _____  __  __ ___     ____   ______   ___     _   __ ____     ______ _   __     __ ____ __  __
                      / ___/ / / / //   |   / __ \ / ____/  /   |   / | / // __ \   / ____// | / /    / // __ \\ \/ /
                      \__ \ / /_/ // /| |  / /_/ // __/    / /| |  /  |/ // / / /  / __/  /  |/ /__  / // / / / \  / 
                     ___/ // __  // ___ | / _, _// /___   / ___ | / /|  // /_/ /  / /___ / /|  // /_/ // /_/ /  / /  
                    /____//_/ /_//_/  |_|/_/ |_|/_____/  /_/  |_|/_/ |_//_____/  /_____//_/ |_/ \____/ \____/  /_/   












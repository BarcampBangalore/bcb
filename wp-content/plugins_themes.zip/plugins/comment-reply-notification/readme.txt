=== Plugin Name ===
Contributors: denishua
Tags: Comment, reply, email, notification
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8490579
Requires at least: 2.7
Tested up to: 3.0.1
Stable tag: 1.4

When a reply is made to a comment the user has left on the blog, an e-mail shall be sent to the user to notify him of the reply. 

== Description ==
<p>When a reply is made to a comment the user has left on the blog, an e-mail shall be sent to the user to notify him of the reply. This will allow the users to follow up the comment and expand the conversation if desired. </p>

<p>Detail information: http://theme10.com/comment-reply-notification/</p>

<p>中文介绍： http://fairyfish.net/2008/11/03/comment-reply-notification/</p>

== Installation ==
<ol>
<li>Upload the folder comment-reply-notification to the `/wp-content/plugins/` directory</li>
<li>Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>Navigate to Manage > Setting > Comment Reply Notification to configure the plugin.</li>
</ol>

== Changelog ==
1.4 2010-10-13 tk (by thomas) : the e-mails are now sent even when the reply is posted from dashboard

1.2 2009-02-18 fix the problem with WP 2.7 paged comments. 

1.0 2008-12-19 inition version
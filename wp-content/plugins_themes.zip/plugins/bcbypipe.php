<?php /**/ ?><?php

/*

Plugin Name: BCB Y Pipe

Plugin URI: http://barcampbangalore.org/

Description: Barcamp Bangalore Yahoo Pipe Plugin

Author: Saurabh Minni

Version: 1

Author URI: http://the100rabh.blogspot.com/

*/



function bcbYPipe($tag)

{



	error_reporting(E_ALL);



	// output=php means that the request will return serialized PHP

	$request =  'http://pipes.yahoo.com/pipes/pipe.run?_id=d83efcace9733ec457913f7291a5c341&_render=php&results_c=4&tag=';

	$request = $request.$tag;

	

	



	$response = file_get_contents($request);



	if ($response === false) {

	    die('Request failed');

	}

	

	$phpobj = unserialize($response);



	if (is_array($phpobj))

	{

	    foreach ($phpobj['value']['items'] AS $key => $val)

	    {

			//printf("<pre>%s</pre>", $val['description']);

			$pos = stripos($val['description'], "<img ", 0);

			if ($pos != FALSE)

			{

				$test = substr($val['description'], $pos + 4, -1);

				$imageTag = sprintf("<img height=75 width=75 %s", $test);

				$firstpart = substr($val['description'], 0, $pos);

//				printf("<div><p><a href=\"%s\">%s</a></p><p>%s%s</p>\n", $val['link'], $val['title'], $firstpart, $imageTag);

				printf("<div> <a href=\"%s\"><p>%s %s</p></a>\n", $val['link'], $firstpart, $imageTag);

			}

			else

			{

//				printf("<div><p><a href=\"%s\">%s</a></p>\n", $val['link'], $val['title']);

//				printf("<div><p><a href=\"%s\">%s</a></p>text<br/><p>%s</p>\n", $val['link'], $val['title'], $val['description']);

				printf("<div><p> %s </p><a href=\"%s\">Link</a><br/><br/>\n", $val['description'], $val['link']);

			}

	    }

	}  

}



function widget_bcbYPipe($args) {

  extract($args);

  echo $before_widget;

  echo $before_title;

  $_url=parse_url( $_SERVER["REQUEST_URI"]);

// $url['path'] = "bcb/sessions/34/";

  $_id = explode('sessions/',$_url['path']);

  $sessionnumber = $_id[1]+0;





  $the_current_session_tag = "BCB9-S".$sessionnumber;

  echo "From the tubes for " ;

  echo $the_current_session_tag;

  echo $after_title;





  bcbYPipe($the_current_session_tag);

  echo $after_widget;

}



function bcbYPipe_init()

{

  register_sidebar_widget(__('BCB Y Plugin'), 'widget_bcbYPipe');

}

add_action("plugins_loaded", "bcbYPipe_init");

?>
<!-- begin footer -->

<div style="clear:both;"></div>

<div id="footer">
	<p>
	
	
	<div id="copyleft"><!--[if lte IE 8]><span style="filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=2); display: inline-block;"><![endif]-->
<span style="-webkit-transform: rotate(180deg); -moz-transform: rotate(180deg); -o-transform: rotate(180deg); -khtml-transform: rotate(180deg); -ms-transform: rotate(180deg); transform: rotate(180deg); display: inline-block;">
        &copy;
</span>
<!--[if lte IE 8]></span><![endif]--> Copyleft. All Wrongs Reserved <a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a> &bull; <a href="http://mixdev.posterous.com" title="Ideas stolen from the internetz"></a> Awesomely Powered by <a href="http://www.wordpress.org">WordPress</a> and <?php echo get_ucount_bcb_link();?> humans. &bull; <a href="http://www.hostaccord.com/">Hosting on HA</a>
	
	
	</div>
	<br />

	<a href="http://twitter.com/barcampbng"><IMG SRC="<?php bloginfo('template_directory'); ?>/images/tweetvamp.png" style="margin-top:25px" WIDTH="200" HEIGHT="121" BORDER="0" ALT="We are tweeting!"></a>
	
	
	</p>
</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18321549-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<?php do_action('wp_footer'); ?>

</body>
</html>

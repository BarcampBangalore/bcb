BarcampBangalore Theme
Theme URL: http://www.barcampbangalore.org/barcamp-theme.htm

This Theme is under GPL License. (http://www.opensource.org/licenses/gpl-license.php)

INSTALL: 
1. Unpack this archive in your wp-content/themes/ directory.
2. Go to Admin WordPress and select presentation.
3. Select Silhouette theme

Questions, bugs and others can be emailed me to arunvijayan@gmail.com

Brian Gardner
arunvijayan
http://webforth.com



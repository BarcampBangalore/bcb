<?php /**/ ?><?php get_header(); ?>

<div id="splashr" style="width:100%; background:url(<?php bloginfo('template_directory'); ?>/images/splashr.jpg) repeat-x;height:336px; margin-bottom:55px; border-bottom:#ccc solid 5px; border-top:#ccc solid 5px">&nbsp;
</div>

<div id="content">



	<div id="contentleft">
<p>
<!-- <h1><strong> Barcamp Bangalore 11 is over</strong></h1><br/>
Thank you all participants for making Barcamp Bangalore 11 a wonderful event.
</p>
-->
<!--
	<strong><font color="green">We have our BCB10 Logo winner </font></strong><br/><br/>
	Dushyanth Raj's logo 
	<img src="/bcb/wp-content/uploads/2011/06/bcb-10-logo-website.jpg">
	<br/>

-->
<p>
<h1><strong> Bangalore Barcamp 12th Edition</strong></h1><br/>

It is happening on <strong>25th August 2012</strong> <a href="http://www.sap.com/"><strong><font color="green">@SAP Labs</font></strong></a>. Registrations for the event are to open soon, read below for details. Read about what we are trying to achieve in our <a href="faq" target="_self"><strong><font color="green">FAQ</font></strong></a> or in detail <a href="about-barcamp"><strong><font color="green">here</font></strong></a><br/>
 
<br/>

<h2>Register for BCB12  </h2>
<p>
Registrations will open soon, please join our mailing list for updates
</p>

<!-- <p> <strong>BCB12 starts at 8:30am. Please be there by then</strong>
</p>
 <p> <h2> Barcamp Bangalore Poster Mash </h2>
Barcamp Bangalore Poster Mash is on. To know more and participate go to <a href="http://barcampbangalore.org/bcb/wp-postermash.php">Poster Mash Page</a>.
<p>
<h2>
Register for BCB11  </h2>
Register for the event by <a href = "http://barcampbangalore.org/bcb/add-a-session" ><font color="green"><strong>Adding a session</font></strong></a> or clicking on <strong>"I'm Attending"</strong> for at least one <a href = "http://barcampbangalore.org/bcb/event/bcb11"><font color="green"><strong>session</font></strong></a> of your interest. Remember that this action requires you to be logged in. If you had registered for last barcamp, you can use	 the same ID/Password to <a href = "http://barcampbangalore.org/bcb/wp-login.php?redirect=http://barcampbangalore.org/bcb/event/bcb11"><font color="green"><strong>login</font></strong></a>. Otherwise <a href="http://barcampbangalore.org/bcb/wp-register.php"><font color="green"><strong>register here</font></strong></a>.
</p> 
-->  
<p>  
To receive the BCB news on your inbox, please join the <a href="http://groups.yahoo.com/group/bangalore_barcamp/" target="_blank"> Barcamp Bangalore Mailing list</a>
</p>

<p> <h2> Barcamp Bangalore Poster Mash </h2>
Barcamp Bangalore Poster Mash is on. To know more and participate go to <a href="http://barcampbangalore.org/bcb/wp-postermash.php">Poster Mash Page</a>.
</p>

<div style="display-haha:none">
Share on twitter 
<a href="http://twitter.com/share" class="twitter-share-button" data-text="I am excited about #BCB12 happening on 25th Aug 2012 at SAP Labs,Whitefield, More at" data-count="none" data-via="barcampbng">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>

 <br/>
<br/>
<iframe src="http://www.facebook.com/plugins/like.php?app_id=164809343583475&amp;href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FBarcamp-Bangalore%2F172593159461976&amp;send=true&amp;layout=standard&amp;width=400&amp;show_faces=true&amp;action=recommend&amp;colorscheme=light&amp;font&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:400px; height:80px;" allowTransparency="true"></iframe>
</p>
<!-- Place this tag in the <head> of your document-->
<link href="https://plus.google.com/106980602201931313067" rel="publisher" /><script type="text/javascript">
(function() 
{var po = document.createElement("script");
po.type = "text/javascript"; po.async = true;po.src = "https://apis.google.com/js/plusone.js";
var s = document.getElementsByTagName("script")[0];
s.parentNode.insertBefore(po, s);
})();</script>

<!-- Place this tag where you want the badge to render-->
<g:plus href="https://plus.google.com/106980602201931313067" size="badge"></g:plus>

</div>
 
<p>

<h2>Venue</h2><br />
<strong>SAP Labs India Pvt. Ltd.,</strong><br/>
#138, EPIP Zone<br/>
Whitefield,<br/>
Bangalore - 560066<br/>
<br/>

Need instructions on reaching the venue?  Right <a href="venue"><strong><font color="green">here</font></strong></a>.<br/>

<br/>
</p>



<!-- <h2>Logo competition</h2><br />
Logo competition is open. Volunteers are encouraged to submit their entry for the logo for Barcamp Bangalore 10 by uploading it to <a href="http://www.facebook.com/pages/Barcamp-Bangalore/172593159461976"><strong><font color="green">Barcamp Bangalore Facebook Page</font></strong></a>.<br/><br/>

Last date for submission of logo's is <strong>3rd June 2011</strong>. <br/>
We will then upload all the photos to facebook  album and open it up for voting by the community.<br/><br/>

You can check out logos of the earlier events: <a href="http://barcampbangalore.org/wiki/BCB9_Logos"><strong><font color="green">BCB9 Logos</strong></font></a>,<a href="http://barcampbangalore.org/wiki/BCB8_Logos"><strong><font color="green">BCB8_Logos</strong></font></a>,<a href="http://barcampbangalore.org/wiki/BCB7_Logos"><strong><font color="green">BCB7_Logos</strong></font></a>, <a href="http://barcampbangalore.org/wiki/BCB6_Logos"><strong><font color="green">BCB6_Logos</strong></font></a>.<br/><br/>


<strong>Resources:</strong> <a href="http://barcamp.org/SpreadBarCamp"> <strong><font color="green">SpreadCamp </strong></font></a><br/><br/>

-->
<p>
<h2>We <3 Tags</h2><br />
Help us spread the word - use these tags:- <br />
<ul>
<li> <strong>Blogging</strong>:  bcb12, bcb, barcampbangalore, barcampbangalore12

<li> <strong>Twitter</strong>: #bcb12

<li> <strong>Flickr</strong>: bcb12, bcb, barcampbangalore, barcampbangalore12
</ul>
</p>



<h2>Feeling nostalgic?  Recollect the previous events</h2><br />

<a href="event/bcb11"><strong><font color="green"> BCB11</strong></font> </a><br/>
<a href="event/bcb10"><strong><font color="green"> BCB10</strong></font> </a><br/>
<a href="event/bcb9"><strong><font color="green"> BCB9</strong></font> </a><br/>
 <a href="event/bcb8"><strong><font color="green"> BCB8</strong></font> </a><br/>
<a href="http://barcampbangalore.org/wiki/Main_Page" target="_blank"><strong><font color="green">Previous Barcamps</font></strong></a>.<br/>

<p>

<h2>New to barcamp?</h2><br />  Don't worry, we have all been there the first time. <br/>

Learn more about Barcamp at <a href="http://en.wikipedia.org/wiki/BarCamp" target="_blank"><strong><font color="green">http://en.wikipedia.org/wiki/BarCamp</font></strong></a>. <br />More on Barcamp Bangalore <a href="about-barcamp"><strong><font color="green">here</font></strong></a><br/>

</p>


<h2>Attending BCB? Tell others</h2>
Please do write about BCB on your blogs, tweet about it using <strong><font color="green"><a href='http://twitter.com/search?q=%23BCB12'>#BCB12</a></strong></font> and spread the word about event. 

<br/>

<p>
<h2>Feedback</h2><br />
Have suggestions about the site?  Want to know what is happening with

the group?  Want to know if the talk idea is ok?  We are listening -

<a href="http://groups.yahoo.com/group/bangalore_barcamp/" target="_blank"><strong><font color="green">http://groups.yahoo.com/group/bangalore_barcamp/</font></strong></a>

</font>

</p>	
	</div>

	

<?php include(TEMPLATEPATH."/l_sidebar.php");?>



<?php include(TEMPLATEPATH."/r_sidebar.php");?>



</div>



<!-- The main column ends  -->



<?php get_footer(); ?>
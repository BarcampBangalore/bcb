<?php /**/ ?><?php

$_CURRENT_BCB_CATEGORY=324;
$_CURRENT_BCB_CATEGORY_EN_SHORT="BCB10";
$DEBUG=false;

//$NAV_ARRAY = "7,5,11";



$NAV_ARRAY = "3";


?>